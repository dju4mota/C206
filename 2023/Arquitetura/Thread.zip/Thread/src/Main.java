public class Main {

    public static void main(String[] args) {

        Thread tInput = new ThreadInput();
        Thread tMusica = new ThreadMusica();


        tMusica.start();
        tInput.start();

    }
}
